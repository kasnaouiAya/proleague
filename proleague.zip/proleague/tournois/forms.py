from django import forms
from .models import Equipe


class EquipeForm(forms.ModelForm):
    class Meta:
        model = Equipe
        fields = ['nom_equipe', 'capitaine', 'logo']
        widgets = {
            'nom_equipe': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nom de votre équipe'
            }),
            'capitaine': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Pseudo du capitaine'
            }),
            'logo': forms.FileInput(attrs={
                'class': 'form-control'
            }),
        }