from django import forms
from .models import Equipe


class EquipeForm(forms.ModelForm):
    class Meta:
        model = Equipe
        fields = ['nom_equipe', 'capitaine', 'logo']
        widgets = {
            'nom_equipe': forms.TextInput(attrs={
                'class': 'form-control form-control-dark',
                'placeholder': 'Nom de votre équipe'
            }),
            'capitaine': forms.TextInput(attrs={
                'class': 'form-control form-control-dark',
                'placeholder': 'Pseudo du capitaine'
            }),
            'logo': forms.FileInput(attrs={
                'class': 'form-control form-control-dark'
            }),
        }