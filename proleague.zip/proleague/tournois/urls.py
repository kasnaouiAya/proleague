from django.urls import path
from . import views

urlpatterns = [
    path('', views.liste_tournois, name='liste_tournois'),
    path('tournoi/<int:pk>/', views.detail_tournoi, name='detail_tournoi'),
    path('tournoi/<int:pk>/inscrire/', views.inscrire_equipe, name='inscrire_equipe'), 
]

