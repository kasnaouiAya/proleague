from django.db import models
from django.contrib.auth.models import User


class Jeu(models.Model):
    PLATEFORME_CHOICES = [
        ('PC', 'PC'),
        ('Console', 'Console'),
    ]

    titre = models.CharField(max_length=100)
    editeur = models.CharField(max_length=100)
    plateforme = models.CharField(max_length=50, choices=PLATEFORME_CHOICES)

    def __str__(self):
        return self.titre


class Tournoi(models.Model):
    nom = models.CharField(max_length=200)
    jeu = models.ForeignKey(Jeu, on_delete=models.CASCADE, related_name='tournois')
    date = models.DateField()
    nb_equipes_max = models.IntegerField()
    cashprize = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return self.nom

    @property
    def est_gros_cashprize(self):
        return self.cashprize >= 1000


class Equipe(models.Model):
    nom_equipe = models.CharField(max_length=100)
    capitaine = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='logos/', blank=True, null=True)
    tournoi = models.ForeignKey(Tournoi, on_delete=models.CASCADE, related_name='equipes')
    date_inscription = models.DateTimeField(auto_now_add=True) 