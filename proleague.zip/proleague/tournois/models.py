from django.db import models


class Jeu(models.Model):
    PLATEFORME_CHOICES = [
        ('PC', 'PC'),
        ('Console', 'Console'),
        ('Mobile', 'Mobile'),
    ]

    titre = models.CharField(max_length=100)
    editeur = models.CharField(max_length=100)
    plateforme = models.CharField(max_length=50, choices=PLATEFORME_CHOICES)

    def __str__(self):
        return self.titre


class Tournoi(models.Model):
    STATUT_CHOICES = [
        ('a_venir', 'À venir'),
        ('en_cours', 'En cours'),
        ('termine', 'Terminé'),
    ]

    nom = models.CharField(max_length=200)
    jeu = models.ForeignKey(Jeu, on_delete=models.CASCADE, related_name='tournois')
    date = models.DateField()
    nb_equipes_max = models.IntegerField(default=8)
    cashprize = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    description_prix = models.TextField(blank=True)
    statut = models.CharField(max_length=20, choices=STATUT_CHOICES, default='a_venir')

    def __str__(self):
        return self.nom

    @property
    def nb_equipes_inscrites(self):
        return self.equipes.count()

    @property
    def places_disponibles(self):
        return self.nb_equipes_max - self.nb_equipes_inscrites

    @property
    def est_complet(self):
        return self.nb_equipes_inscrites >= self.nb_equipes_max

    @property
    def est_gros_cashprize(self):
        return self.cashprize >= 1000


class Equipe(models.Model):
    nom_equipe = models.CharField(max_length=100)
    capitaine = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='logos/', blank=True, null=True)
    tournoi = models.ForeignKey(Tournoi, on_delete=models.CASCADE, related_name='equipes')
    date_inscription = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.nom_equipe