from django.contrib import admin
from .models import Jeu, Tournoi, Equipe


@admin.register(Jeu)
class JeuAdmin(admin.ModelAdmin):
    list_display = ['titre', 'editeur', 'plateforme']
    list_filter = ['plateforme']
    search_fields = ['titre']


@admin.register(Tournoi)
class TournoiAdmin(admin.ModelAdmin):
    list_display = ['nom', 'jeu', 'date', 'statut', 'cashprize']
    list_filter = ['jeu', 'statut', 'date']
    search_fields = ['nom']
    date_hierarchy = 'date'


@admin.register(Equipe)
class EquipeAdmin(admin.ModelAdmin):
    list_display = ['nom_equipe', 'capitaine', 'tournoi']
    search_fields = ['nom_equipe', 'capitaine']