from django.contrib import admin
from .models import Jeu, Tournoi, Equipe


@admin.register(Jeu)
class JeuAdmin(admin.ModelAdmin):
    list_display = ('titre', 'editeur', 'plateforme')
    list_filter = ('plateforme',)
    search_fields = ('titre', 'editeur')


@admin.register(Tournoi)
class TournoiAdmin(admin.ModelAdmin):
    list_display = ('nom', 'jeu', 'date', 'cashprize', 'nb_equipes_max')
    list_filter = ('jeu', 'date')
    search_fields = ('nom',)
    date_hierarchy = 'date'


@admin.register(Equipe)
class EquipeAdmin(admin.ModelAdmin):
    list_display = ('nom_equipe', 'capitaine', 'tournoi')
    list_filter = ('tournoi',)
    search_fields = ('nom_equipe', 'capitaine')