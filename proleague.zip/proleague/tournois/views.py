from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Q
from django.utils import timezone
from .models import Tournoi, Jeu
from .forms import EquipeForm


def liste_tournois(request):
    tournois = Tournoi.objects.all()
    jeux = Jeu.objects.all()
    
    q = request.GET.get('q')
    if q:
        tournois = tournois.filter(
            Q(nom__icontains=q) | Q(jeu__titre__icontains=q)
        )
    
    jeu_id = request.GET.get('jeu')
    if jeu_id:
        tournois = tournois.filter(jeu_id=jeu_id)
    
    filtre = request.GET.get('filtre')
    if filtre == 'avenir':
        tournois = tournois.filter(date__gte=timezone.now().date())
    elif filtre == 'gros_prix':
        tournois = tournois.filter(cashprize__gte=1000)
    
    context = {
        'tournois': tournois,
        'jeux': jeux,
        'today': timezone.now().date(),
    }
    return render(request, 'tournois/liste_tournois.html', context)


def detail_tournoi(request, pk):
    tournoi = get_object_or_404(Tournoi, pk=pk)
    return render(request, 'tournois/detail_tournoi.html', {
        'tournoi': tournoi,
        'today': timezone.now().date(),
    })


def inscrire_equipe(request, pk):
    tournoi = get_object_or_404(Tournoi, pk=pk)
    
    if tournoi.equipes.count() >= tournoi.nb_equipes_max:
        return redirect('detail_tournoi', pk=pk)
    
    if tournoi.date < timezone.now().date():
        return redirect('detail_tournoi', pk=pk)
    
    if request.method == 'POST':
        form = EquipeForm(request.POST, request.FILES)
        if form.is_valid():
            equipe = form.save(commit=False)
            equipe.tournoi = tournoi
            equipe.save()
            return redirect('detail_tournoi', pk=pk)
    else:
        form = EquipeForm()
    
    context = {
        'tournoi': tournoi,
        'form': form,
    }
    return render(request, 'tournois/inscrire_equipe.html', context)