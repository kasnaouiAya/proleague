from django.shortcuts import render, get_object_or_404 , redirect
from django.db.models import Q
from .models import Tournoi, Jeu
from .forms import EquipeForm
from django.contrib import messages

def liste_tournois(request):
    """Page d'accueil avec liste et filtres"""
    tournois = Tournoi.objects.all()
    jeux = Jeu.objects.all()
    
    # ===== DEBUG =====
    print("=" * 50)
    print(f"NOMBRE TOTAL DE TOURNOIS: {tournois.count()}")
    for t in tournois:
        print(f"  - ID:{t.id} | NOM:{t.nom} | JEU:{t.jeu} | STATUT:{t.statut} | PRIX:{t.cashprize}")
    print(f"NOMBRE TOTAL DE JEUX: {jeux.count()}")
    for j in jeux:
        print(f"  - ID:{j.id} | TITRE:{j.titre}")
    print("=" * 50)
    # =================
    
    # Filtre par recherche
    q = request.GET.get('q')
    if q:
        tournois = tournois.filter(
            Q(nom__icontains=q) | Q(jeu__titre__icontains=q)
        )
    
    # Filtre par jeu (vérifie non vide)
    jeu_id = request.GET.get('jeu')
    if jeu_id and jeu_id.strip():
        tournois = tournois.filter(jeu_id=jeu_id)
    
    # Filtre par statut (vérifie non vide)
    statut = request.GET.get('statut')
    if statut and statut.strip():
        tournois = tournois.filter(statut=statut)
    
    # Filtre par prix (vérifie non vide)
    prix = request.GET.get('prix')
    if prix and prix.strip():
        if prix == 'gros':
            tournois = tournois.filter(cashprize__gte=1000)
        elif prix == 'petit':
            tournois = tournois.filter(cashprize__lt=1000)
    
    # ===== DEBUG APRÈS FILTRES =====
    print(f"APRÈS FILTRES: {tournois.count()} tournois")
    print("=" * 50)
    # ================================
    
    context = {
        'tournois': tournois,
        'jeux': jeux,
    }
    return render(request, 'tournois/liste_tournois.html', context)

def detail_tournoi(request, pk):
    """Page détail d'un tournoi"""
    tournoi = get_object_or_404(Tournoi, pk=pk)
    return render(request, 'tournois/detail_tournoi.html', {'tournoi': tournoi})


def inscrire_equipe(request, pk):
    """Inscrire une équipe à un tournoi"""
    tournoi = get_object_or_404(Tournoi, pk=pk)
    
    # Vérifications
    if tournoi.est_complet:
        messages.error(request, "Ce tournoi est complet !")
        return redirect('detail_tournoi', pk=pk)
    
    if tournoi.statut != 'a_venir':
        messages.error(request, "Les inscriptions sont fermées pour ce tournoi.")
        return redirect('detail_tournoi', pk=pk)
    
    if request.method == 'POST':
        form = EquipeForm(request.POST, request.FILES)
        if form.is_valid():
            equipe = form.save(commit=False)
            equipe.tournoi = tournoi
            equipe.save()
            messages.success(request, f"Équipe '{equipe.nom_equipe}' inscrite avec succès !")
            return redirect('detail_tournoi', pk=pk)
    else:
        form = EquipeForm()
    
    context = {
        'tournoi': tournoi,
        'form': form,
    }
    return render(request, 'tournois/inscrire_equipe.html', context)